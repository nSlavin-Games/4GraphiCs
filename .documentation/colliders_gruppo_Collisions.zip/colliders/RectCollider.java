package com.fourgraphics.colliders;

import com.fourgraphics.gameobjects.GameObject;
import com.fourgraphics.gameobjects.Vector2;

import processing.core.PApplet;

/**
 * @author Gruppo Collisions
 * La classe rappresenta un collider rettangolare
 */
public class RectCollider extends Collider {

	/**
	 * costruttore con un parametro
	 * @param dynamicObject
	 */
	public RectCollider(boolean dynamicObject) {

		super(dynamicObject);

	}

	/**
	 * costruttore con due parametri
	 * @param dynamicObject
	 * @param sketch
	 */
	public RectCollider(boolean dynamicObject, PApplet sketch) {

		super(dynamicObject, sketch);

	}

	/**
	 * il metodo prende come parametro un collider 
	 * il metodo verifica se avviene la collisione tra il collider rettangolare e il collider preso come parametro
	 * il collider preso come parametro pu� essere rettangolare o circolare
	 * @return il lato in cui � avvenuta la collisione
	 */
	public CollisionDirection CheckCollision(Collider other) {

		if (isDebug() == true) { //se la variabile debug � true disegna graficamente il collider rettangolare (per test)
			sketch.rectMode(sketch.CENTER);
			sketch.fill(0, 255, 0, 200);
			sketch.rect(transform.getPosition().getX(), transform.getPosition().getY(), transform.getScale().getX(),
					transform.getScale().getY());

		}

		//se il collider preso come parametro � rettangolare
		if (other instanceof RectCollider) {

			if (isDebug() == true) { //se la variabile debug � true disegna graficamente il collider rettangolare preso come parametro (per test)
				sketch.rectMode(sketch.CENTER);
				sketch.fill(255, 0, 0, 200);
				sketch.rect(other.transform.getPosition().getX(), other.transform.getPosition().getY(),
						other.transform.getScale().getX(), other.transform.getScale().getY());

			}

			float distx = transform.getPosition().getX() - other.transform.getPosition().getX(); //distanza tra le x del centro dei due collider
			float disty = transform.getPosition().getY() - other.transform.getPosition().getY(); //distanza tra le y del centro dei due collider

			float hWidths = transform.getScale().getX() / 2 + other.transform.getScale().getX() / 2; //somma della met� della lunghezza dei due collider
			float hHeights = transform.getScale().getY() / 2 + other.transform.getScale().getY() / 2; //somma della met� dell'altezza dei due collider

			//variabili utilizzate per capire su quale lato c'� stata una maggiore collisione
			float overlapX = hWidths - Math.abs(distx); 
			float overlapY = hHeights - Math.abs(disty);

			if (Math.abs(distx) <= hWidths && Math.abs(disty) <= hHeights) { //verifica se � avvenuta la collisione

				//viene restituita la direzione dove � avvenuta la collisione rispetto al collider rettangolare (non quello preso come parametro)
				
				if (overlapX > overlapY) { //la collisione � avvenuta principalmente sulla y

					
					if (disty > 0) { 
						return CollisionDirection.UP; //la collisione � avvenuta in alto
				
					} else {
						return CollisionDirection.DOWN; //la collisione � avvenuta in basso
					
					}

				}

				if (overlapY > overlapX) { //la collisione � avvenuta principalmente sulla x

					if (distx > 0) {
						return CollisionDirection.LEFT; //la collisione � avvenuta a sinistra
				
					} else {
						return CollisionDirection.RIGHT; //la collisione � avvenuta a destra
					
					}

				}

			}

		}
		
		//se il collider preso come parametro � circolare
		if (other instanceof CircleCollider) {

			if (isDebug() == true) { //se la variabile debug � true disegna graficamente il collider circolare preso come parametro (per test)
				sketch.fill(255, 0, 0, 200);
				sketch.circle(other.transform.getPosition().getX(), other.transform.getPosition().getY(),
						other.transform.getScale().getX());
			}


			float distx = other.transform.getPosition().getX() - transform.getPosition().getX(); //distanza tra le x del centro dei due collider
			float disty = other.transform.getPosition().getY() - transform.getPosition().getY(); //distanza tra le y del centro dei due collider

			float hWidths = other.transform.getScale().getX() / 2 + transform.getScale().getX() / 2; //somma della met� della lunghezza dei due collider
			float hHeights = other.transform.getScale().getX() / 2 + transform.getScale().getY() / 2; //somma della met� dell'altezza dei due collider

			//variabili utilizzate per capire su quale lato c'� stata una maggiore collisione
			float overlapX = hWidths - Math.abs(distx);
			float overlapY = hHeights - Math.abs(disty);
			
			//coordinate del collider preso come parametro
			float testX = other.transform.getPosition().getX();
			float testY = other.transform.getPosition().getY();
			
			//viene restituita la direzione dove � avvenuta la collisione rispetto al collider rettangolare (non quello preso come parametro)
			
			if(overlapX > overlapY)
			{
				if(disty > 0)
				{
					testY = transform.getPosition().getY()+transform.getScale().getY()/2;
					float dy = other.transform.getPosition().getY() - testY;
					float distance = (float)Math.sqrt(dy*dy);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione in basso
					{
				
						return CollisionDirection.DOWN; //la collisione � avvenuta in basso
					}
					
				} else
				{
					testY = transform.getPosition().getY()-transform.getScale().getY()/2;
					float dy = other.transform.getPosition().getY() - testY;
					float distance = (float)Math.sqrt(dy*dy);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione in alto
					{
				
						return CollisionDirection.UP; //la collisione � avvenuta in alto
					}
				}
			} else
			{
				if(distx > 0)
				{
					testX = transform.getPosition().getX()+transform.getScale().getX()/2;
					float dx = other.transform.getPosition().getX() - testX;
					float distance = (float)Math.sqrt(dx*dx);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione a destra
					{
					
						return CollisionDirection.RIGHT; //la collisione � avvenuta a destra
					}
					
				} else
				{
					testX = transform.getPosition().getX()-transform.getScale().getX()/2;
					float dx = other.transform.getPosition().getX() - testX;
					float distance = (float)Math.sqrt(dx*dx);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione a sinistra
					{
				
						return CollisionDirection.LEFT; //la collisione � avvenuta a sinistra
					}
				}
			}
		}

		return CollisionDirection.NONE; //non � avvenuta nessuna collisione

	}
	
	

	/**
	 * il metodo prende come parametro un collider 
	 * il metodo verifica se avviene la collisione tra il collider rettangolare e il collider preso come parametro
	 * il collider preso come parametro pu� essere rettangolare o circolare
	 * @return il lato in cui � avvenuta la collisione
	 * blocca il collider al collider confrontato
	 */
	public CollisionDirection CheckCollisionSnap(Collider other) {

		if (isDebug() == true) { // se la variabile debug � true disegna graficamente il collider rettangolare (per test)
			sketch.rectMode(sketch.CENTER);
			sketch.fill(0, 255, 0, 200);
			sketch.rect(transform.getPosition().getX(), transform.getPosition().getY(), transform.getScale().getX(),
					transform.getScale().getY());

		}

		if (other instanceof RectCollider) { //se il collider preso come parametro � rettangolare

			if (isDebug() == true) { //se la variabile debug � true disegna graficamente il collider rettangolare preso come parametro (per test)
				sketch.rectMode(sketch.CENTER);
				sketch.fill(255, 0, 0, 200);
				sketch.rect(other.transform.getPosition().getX(), other.transform.getPosition().getY(),
						other.transform.getScale().getX(), other.transform.getScale().getY());

			}

			float distx = transform.getPosition().getX() - other.transform.getPosition().getX(); //distanza tra le x del centro dei due collider
			float disty = transform.getPosition().getY() - other.transform.getPosition().getY(); //distanza tra le y del centro dei due collider

			float hWidths = transform.getScale().getX() / 2 + other.transform.getScale().getX() / 2; //somma della met� della lunghezza dei due collider
			float hHeights = transform.getScale().getY() / 2 + other.transform.getScale().getY() / 2; //somma della met� dell'altezza dei due collider

			//variabili utilizzate per capire su quale lato c'� stata una maggiore collisione
			float overlapX = hWidths - Math.abs(distx);
			float overlapY = hHeights - Math.abs(disty);

			if (Math.abs(distx) <= hWidths && Math.abs(disty) <= hHeights) { //verifica se � avvenuta la collisione

				//viene restituita la direzione dove � avvenuta la collisione rispetto al collider rettangolare (non quello preso come parametro)
				
				transform.setPosition(transform.getPosition().getX(),transform.getPosition().getY()); 
				if (overlapX > overlapY) {

					if (disty > 0) {
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setY(other.transform.getPosition().getY()
								+other.transform.getScale().getX()/2
								+transform.getScale().getX()/2);
						return CollisionDirection.UP; //la collisione � avvenuta in alto
						
					} else {
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setY(other.transform.getPosition().getY()
								-other.transform.getScale().getX()/2
								-transform.getScale().getX()/2);
						return CollisionDirection.DOWN; //la collisione � avvenuta in basso
					
					}

				}

				if (overlapY > overlapX) {

					if (distx > 0) {
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setX(other.transform.getPosition().getX()
								+other.transform.getScale().getX()/2
								+transform.getScale().getX()/2);
						return CollisionDirection.LEFT; //la collisione � avvenuta a sinistra
						
					} else {
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setX(other.transform.getPosition().getX()
								-other.transform.getScale().getX()/2
								-transform.getScale().getX()/2);
						return CollisionDirection.RIGHT; //la collisione � avvenuta a destra
			
					}

				}

			}

		}
		
		//se il collider preso come parametro � circolare
		if (other instanceof CircleCollider) {

			if (isDebug() == true) { //se la variabile debug � true disegna graficamente il collider circolare preso come parametro (per test)
				sketch.fill(255, 0, 0, 200);
				sketch.circle(other.transform.getPosition().getX(), other.transform.getPosition().getY(),
						other.transform.getScale().getX());
			}


			float distx = other.transform.getPosition().getX() - transform.getPosition().getX(); //distanza tra le x del centro dei due collider
			float disty = other.transform.getPosition().getY() - transform.getPosition().getY(); //distanza tra le y del centro dei due collider

			float hWidths = other.transform.getScale().getX() / 2 + transform.getScale().getX() / 2; //somma della met� della lunghezza dei due collider
			float hHeights = other.transform.getScale().getX() / 2 + transform.getScale().getY() / 2; //somma della met� dell'altezza dei due collider

			//variabili utilizzate per capire su quale lato c'� stata una maggiore collisione
			float overlapX = hWidths - Math.abs(distx);
			float overlapY = hHeights - Math.abs(disty);

			//coordinate del collider preso come parametro
			float testX = other.transform.getPosition().getX();
			float testY = other.transform.getPosition().getY();
			
			//viene restituita la direzione dove � avvenuta la collisione rispetto al collider rettangolare (non quello preso come parametro)
			
			if(overlapX > overlapY)
			{
				if(disty > 0)
				{
					testY = transform.getPosition().getY()+transform.getScale().getY()/2;
					float dy = other.transform.getPosition().getY() - testY;
					float distance = (float)Math.sqrt(dy*dy);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione in basso
					{
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setY(other.transform.getPosition().getY()
								-other.transform.getScale().getX()/2
								-transform.getScale().getX()/2);
						return CollisionDirection.DOWN; //la collisione � avvenuta in basso
					}
					
				} else
				{
					testY = transform.getPosition().getY()-transform.getScale().getY()/2;
					float dy = other.transform.getPosition().getY() - testY;
					float distance = (float)Math.sqrt(dy*dy);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione in alto
					{
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setY(other.transform.getPosition().getY()
								+other.transform.getScale().getX()/2
								+transform.getScale().getX()/2);
						return CollisionDirection.UP; //la collisione � avvenuta in alto
					}
				}
			} else
			{
				if(distx > 0)
				{
					testX = transform.getPosition().getX()+transform.getScale().getX()/2;
					float dx = other.transform.getPosition().getX() - testX;
					float distance = (float)Math.sqrt(dx*dx);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione a destra
					{
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setX(other.transform.getPosition().getX()
								-other.transform.getScale().getX()/2
								-transform.getScale().getX()/2);
						return CollisionDirection.RIGHT; //la collisione � avvenuta a destra
					}
					
				} else
				{
					testX = transform.getPosition().getX()-transform.getScale().getX()/2;
					float dx = other.transform.getPosition().getX() - testX;
					float distance = (float)Math.sqrt(dx*dx);
					if(distance <= other.transform.getScale().getX()/2) //verifica se � avvenuta la collisione a sinistra
					{
						//la posizione del collider viene bloccata dove avviene la collisione con l'altro collider (quello preso come parametro) 
						transform.getPosition().setX(other.transform.getPosition().getX()
								+other.transform.getScale().getX()/2
								+transform.getScale().getX()/2);
						return CollisionDirection.LEFT;  //la collisione � avvenuta a sinistra
					}
				}
			}
		}
		
		return CollisionDirection.NONE; //non � avvenuta nessuna collisione

	}
}