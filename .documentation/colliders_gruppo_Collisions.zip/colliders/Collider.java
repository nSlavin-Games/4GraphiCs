package com.fourgraphics.colliders;

import com.fourgraphics.gameobjects.GameObject;
import com.fourgraphics.gameobjects.Vector2;
import com.fourgraphics.scenemanagement.SceneManager;

import processing.core.PApplet;

import com.fourgraphics.gameobjects.Transform;

/**
 * @author Gruppo Collisions
 * La classe di base per le collisioni, ha un riferimento all�oggetto che lo contiene e alla sua posizione e dimensione
 */
abstract public class Collider {
	
	public GameObject gameObject; //l�oggetto a cui � attaccato questo componente
	Vector2 previousPosition; //la posizione precedente del collider
	public Transform  transform; //la posizione e la dimensione dell�oggetto a cui � attaccato questo componente
	private boolean dynamicObject; //indica se l�oggetto dovrebbe muoversi oppure no
	private boolean debug; //se � true disegna i collider, serve per testare graficamente le collisioni
	protected PApplet sketch; //oggetto PApplet
	
	
	/**
	 * costruttore con un parametro
	 * @param dynamicObject
	 */
	public Collider(boolean dynamicObject) {
		
		setDynamic(dynamicObject); //viene settata la variabile dynamicObject
		sketch=SceneManager.getApp(); //metodo statico che ritorna il riferimento all'oggetto processing del main
	}
	
	/**
	 * costruttore con due parametri
	 * @param dynamicObject
	 * @param sketch
	 */
	public Collider(boolean dynamicObject, PApplet sketch) {
		
		setDynamic(dynamicObject); //viene settata la variabile dynamicObject
		this.sketch=sketch;
	}
	
	
	abstract CollisionDirection CheckCollision(Collider other); //metodo astratto
	
	abstract CollisionDirection CheckCollisionSnap(Collider other); //metodo astratto

//set e get delle variabili dynamicObject e debug
	
	public boolean isDynamic() {
		return dynamicObject;
	}


	public void setDynamic(boolean dynamicObject) {
		this.dynamicObject = dynamicObject;
	}


	public boolean isDebug() {
		return debug;
	}


	public void setDebug(boolean debug) {
		this.debug = debug;
	}
	
	
	
	

}