package com.fourgraphics.colliders;

/**
 * @author Gruppo Collisions
 * direzione dove � avvenuta la collisione
 */
public enum CollisionDirection {
	
	NONE,
	RIGHT,
	LEFT,
	UP,
	DOWN;
}
